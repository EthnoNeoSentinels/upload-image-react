module.exports = {
  trailingComma: 'all',
  endOfLine: 'auto',
  semi: true,
  singleQuote: true,
  printWidth: 120,
  useTabs: true,
  tabWidth: 4,
};
