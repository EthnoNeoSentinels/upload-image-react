# Extensions

## Abstract
The extensions are special functions that are helpful to extend standard functional of the cropper.

Some of them can be included in default functional later.

## List

### Absolute Zoom

The functions that give you possibility to get the current absolute zoom and to set the absolute zoom value.

### Prevent Zoom

The postprocess function that prevents image zoom in different occasions. 

### Stencil Size

The couple of functions that give the developer possibility to set fixed stencil size in pixels.
